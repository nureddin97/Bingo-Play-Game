/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bingo;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author acer
 */
public class linkedList {

    Node head;

    public void addLast(int data1, int data2, int data3) {
        Node newNode1 = new Node(data1);
        Node newNode2 = new Node(data2);
        Node newNode3 = new Node(data3);

        if (head == null) {
            head = newNode1;
            head.down = newNode2;
            newNode2.down = newNode3;
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }

            temp.next = newNode1;
            newNode1.down = newNode2;
            newNode2.down = newNode3;
        }
    }

    public void generateNumbers() {
        Random rand = new Random();
        int getNumber1;
        int getNumber2;
        int getNumber3;
        int max = 9;
        int min = 1;
        for (int i = 0; i < 9; i++) {
            getNumber1 = rand.nextInt(max - min + 1) + min;
            getNumber2 = rand.nextInt(max - min + 1) + min;
            getNumber3 = rand.nextInt(max - min + 1) + min;
            while (!(getNumber1 < getNumber2) || !(getNumber2 < getNumber3)) {
                getNumber1 = rand.nextInt(max - min + 1) + min;
                getNumber2 = rand.nextInt(max - min + 1) + min;
                getNumber3 = rand.nextInt(max - min + 1) + min;
            }
            addLast(getNumber1, getNumber2, getNumber3);
            max += 10;
            min += 10;
        }
    }

    public void createCard() {

        Random rand = new Random();

        for (int k = 0; k < 3; k++) {
            int block1, block2, block3, block4;
            block1 = rand.nextInt(3);
            block2 = rand.nextInt(2) + 3;
            block3 = rand.nextInt(2) + 5;
            block4 = rand.nextInt(2) + 7;
            Node temp = head;
            for (int j = 0; j < 9; j++) {
                switch (k) {
                    case 0:
                        if (j == block1 || j == block2 || j == block3 || j == block4) {
                            temp.data = -1;
                            System.out.print(temp.data + "  ");
                        } else {
                            System.out.print(temp.data + "  ");
                        }
                        break;
                    case 1:
                        if (j == block1 || j == block2 || j == block3 || j == block4) {
                            temp.down.data = -1;
                            System.out.print(temp.down.data + "  ");
                        } else {
                            System.out.print(temp.down.data + "  ");
                        }
                        break;
                    default:
                        if (j == block1 || j == block2 || j == block3 || j == block4) {
                            temp.down.down.data = -1;
                            System.out.print(temp.down.down.data + "  ");
                        } else {
                            System.out.print(temp.down.down.data + "  ");
                        }
                        break;
                }

                temp = temp.next;
            }

            System.out.println();
        }
    }

    public void checkNumbers2(int randomNums[]) {

        System.out.println();
        for (int m = 0; m < 3; m++) {
            Node temp = head;
            for (int j = 0; j < 9; j++) {

                switch (m) {
                    case 0:
                        if (temp.data == randomNums[0] || temp.data == randomNums[1] || temp.data == randomNums[2] || temp.data == randomNums[3] || temp.data == randomNums[4]) {
                            temp.data = -1;
                            System.out.print(temp.data + "  ");
                        } else {
                            System.out.print(temp.data + "  ");
                        }
                        break;
                    case 1:
                        if (temp.down.data == randomNums[0] || temp.down.data == randomNums[1] || temp.down.data == randomNums[2] || temp.down.data == randomNums[3] || temp.down.data == randomNums[4]) {
                            temp.down.data = -1;
                            System.out.print(temp.down.data + "  ");
                        } else {
                            System.out.print(temp.down.data + "  ");
                        }
                        break;
                    default:
                        if (temp.down.down.data == randomNums[0] || temp.down.down.data == randomNums[1] || temp.down.down.data == randomNums[2] || temp.down.down.data == randomNums[3] || temp.down.down.data == randomNums[4]) {
                            temp.down.down.data = -1;
                            System.out.print(temp.down.down.data + "  ");
                        } else {
                            System.out.print(temp.down.down.data + "  ");
                        }
                        break;
                }
                temp = temp.next;
            }
            System.out.println();

        }

    }

    public boolean checking() {
        int row1Count, row2Count, row3Count;
        row1Count = row2Count = row3Count = 0;

        Node temp = head;
        for (int j = 0; j < 9; j++) {
            if (temp.data == -1) {
                row1Count++;
            }
            if (temp.down.data == -1) {
                row2Count++;
            }
            if (temp.down.down.data == -1) {
                row3Count++;
            }
            temp = temp.next;
        }

        if (row1Count == 9 || row2Count == 9 || row3Count == 9) {
            System.out.println("(birinci çinko)");

            if (row1Count == 9 && row2Count == 9 || row1Count == 9 && row3Count == 9 || row2Count == 9 && row3Count == 9) {
                System.out.println("(ikinci çinko)");
            }
            if (row1Count == 9 && row2Count == 9 && row3Count == 9) {
                System.out.println("(tombala)");
                return true;
            }

        }
        return false;
    }

}
