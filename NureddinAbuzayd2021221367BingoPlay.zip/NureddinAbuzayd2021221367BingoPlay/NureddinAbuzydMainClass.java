/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.bingo;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author acer
 */
public class NureddinAbuzydMainClass {

    public static void main(String[] args) {
//        int count = -12;
        linkedList player1 = new linkedList();
        linkedList player2 = new linkedList();
        System.out.println("First Player:");
        player1.generateNumbers();
        player1.createCard();

        System.out.println("");
        System.out.println("Second Player:");
        player2.generateNumbers();
        player2.createCard();

        System.out.println("********************************************");
        Random generatePermutation = new Random();
        int[] randomNums = new int[5];
        boolean isTrue = true;
        while (isTrue) {
            for (int i = 0; i < randomNums.length; i++) {
                int rand = generatePermutation.nextInt(89);
                randomNums[i] = rand;
                System.out.print(randomNums[i] + ", ");
                if (i == 4) {
                    System.out.println("");
                }
            }

            System.out.println("First Player:");
            player1.checkNumbers2(randomNums);
            if (player1.checking()) {
                isTrue = false;
            }
            System.out.println("Second Player:");
            player2.checkNumbers2(randomNums);

            if (player2.checking()) {
                isTrue = false;

            }
        }
    }
}
